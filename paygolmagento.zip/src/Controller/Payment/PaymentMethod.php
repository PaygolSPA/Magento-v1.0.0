<?php

namespace Paygol\PaygolMagento\Controller\Payment;

use Paygol\PaygolCore\PaygolApi;

class PaymentMethod extends \Magento\Framework\App\Action\Action
{
   /**
    * @var \Magento\Framework\Controller\Result\JsonFactory
    */
   protected $_resultJsonFactory;

   /**
    * @var \Psr\Log\LoggerInterface
    */
   protected $_logger;

   /**
    * @var \Paygol\PaygolMagento\Model\Factory\Connector
    */
   protected $_tpConnector;

   public function __construct(
      \Paygol\PaygolMagento\Model\Factory\Connector $tpc,
      \Magento\Framework\App\Action\Context $context,
      \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
      \Psr\Log\LoggerInterface $logger
   ) {
      parent::__construct($context);
      $this->_resultJsonFactory = $resultJsonFactory;
      $this->_logger = $logger;
      $this->_tpConnector = $tpc;
   }

   protected function _getCheckoutSession()
   {
      return $this->_checkoutSession;
   }

   public function execute()
   {
      $types = [];
      $error_message = '';
      try {
         $paygol = new PaygolApi(
            $this->_tpConnector->getTokenService(),
            $this->_tpConnector->getTokenSecret(),
            $this->_tpConnector->getEnviroment()
         );

         $patmentMethods = $paygol->getPaymentMethods('CL');
         $types = $patmentMethods['methods'];
      } catch (\Exception $exception) {
         $error_message = $exception->getMessage();
         $this->_logger->debug('Error ' . print_r($exception->getMessage(), true));
      }
      $result = $this->_resultJsonFactory->create();
      return $result->setData([
         'types' => $types,
         'error_message' => $error_message,
      ]);
   }
}
